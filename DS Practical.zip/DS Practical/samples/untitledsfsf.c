#include <stdio.h>

int main(){
	
	int i; 
	
	float x; 
	char name[50];
	
	scanf("%2d%f%*d%[1234567890]", &i, &x, name);
	
	
	
	printf("%d \n\n %f \n\n %s", i,x,name);
	
	return 0;
	
}
