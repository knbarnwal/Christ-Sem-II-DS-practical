#include<stdio.h>
#include<stdlib.h>
 
struct node
{
    int data;
    struct node* next;
};
 
struct node* sortedmerge(struct node* a, struct node* b);
void frontbacksplit(struct node* source, struct node** frontRef, struct node** backRef);
 
void push(struct node** head_ref, int new_data)
{
    struct node* new_node = (struct node*) malloc(sizeof(struct node));
    new_node -> data  = new_data;
    new_node->next = (*head_ref);
    (*head_ref) = new_node;
}

void frontbacksplit(struct node* source, struct node** frontRef, struct node** backRef)
{
    struct node* fast;
    struct node* slow;
    if (source==NULL || source->next==NULL)
    {
        *frontRef = source;
        *backRef = NULL;
    }
    else
    {
        slow = source;
        fast = source -> next;
        while (fast != NULL)
        {
            fast = fast -> next;
            if (fast != NULL)
            {
                slow = slow -> next;
                fast = fast -> next;
            }
    }
 
    *frontRef = source;
    *backRef = slow -> next;
    slow -> next = NULL;
    }
}

void mergesort(struct node** headRef)
{
    struct node* head = *headRef;
    struct node* a;
    struct node* b;
    if ((head == NULL) || (head -> next == NULL))
    {
        return;
    }
    frontbacksplit(head, &a, &b);
    mergesort(&a);
    mergesort(&b);
    *headRef = sortedmerge(a, b);
}
 
struct node* sortedmerge(struct node* a, struct node* b)
{
    struct node* result = NULL;
 
    if (a == NULL)
        return(b);
    else if (b == NULL)
        return(a);
 
    if ( a-> data <= b -> data)
    {
        result = a;
        result -> next = sortedmerge(a -> next, b);
    }
    else
    {
        result = b;
        result -> next = sortedmerge(a, b -> next);
    }
    return(result);
}
 
void printlist(struct node *node)
{
    while(node != NULL)
    {
        printf("\t%d\t", node -> data);
        node = node -> next;
    }
}

int main()
{
    struct node* a = NULL;
    int i,n,arr[20],status,temp;
    printf("\n\t\t\tImplementation of Mergesort using Linked List\n\n ");
	printf("\n Enter number of elements:\n");
    status = scanf(" %d",&n);
    while(status != 1)
	{
		while((temp=getchar()) != EOF && temp != '\n');
		printf("Invalid input...\nPlease enter a number: \t");
		status = scanf("%d", &n);
	}
    printf("\n Enter the list of elements\n");
    for(i=0;i<n;i++)
    {
    	printf("\nElement %d:\t", (i+1));
    	status = scanf(" %d",&arr[i]);
    	while(status != 1)
		{
			while((temp=getchar()) != EOF && temp != '\n');
			printf("Invalid input...\nPlease enter a number: ");
			status = scanf("%d", &arr[i]);
		}
	}
	for(i=0;i<n;i++)
    {
    	push(&a,arr[i]);
	}
    
 
    printf("\n\t Linked List before sorting\n\n");
    for(i=0;i<n;i++)
    {
    	printf("\t%d\t",arr[i]);
	}
 	printf("\n");
 	
    mergesort(&a);
 
    printf("\n\n\t Linked List after sorting\n\n");
    printlist(a);
 
    return 0;
}
