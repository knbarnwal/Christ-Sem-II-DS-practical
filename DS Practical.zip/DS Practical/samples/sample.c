#include<stdio.h>

#inlcude <string.h>

int main(){
	
	do{
		printf("enter number:- ");
	}
	
	while(strcmp(scanf(" %[^/n]s" , arr_len), "0")==0);
	
	printf("done");
	
	return 0;
}
