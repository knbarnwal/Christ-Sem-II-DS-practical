

// Implement sequential search and binary search techniques. 
// Return 1 false return 0 always true

/*******************************************************************************
 *  Implement sequential search and binary search techniques                   *
 *     																		   *
 *******************************************************************************/

/**************************************************************************
 *                                                                        *
 * 		               Header Files Used                                  *
 *                                                                        *
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

  /**************************************************************************
   *                                                                        *
   * 			Used Macros as NUM and ONE to store Value of 6 and 1        *
   *                                                                        *
   **************************************************************************/

  #define NUM 6
  #define ONE 1


  /**************************************************************************
   *                                                                        *
   * 	Gotoxy() is used to set the curser on the manual location           *
   *                                                                        *
   **************************************************************************/

typedef struct search_operations{
	int elements[100];
	char names[30];
	
}s;

s srch;
s str[99];

void back_exit();
int Welcome_for_int();
int welcome_for_string();
void Welcome();

void print_elements();

void gotoxy(int x,int y){
	
	printf("%c[%d;%df",0x1B,y,x);
	
}

  /**************************************************************************
   *                                                                        *
   * 			Box Function to make (**) border box in the program         *
   *                                                                        *
   **************************************************************************/

void box(){
	
	int hor_row, ver_col;
	
	for(hor_row=10; hor_row<70; hor_row++){
		gotoxy(hor_row, 3);
			printf("*");
		gotoxy(hor_row, 4);
			printf("*");
		
		
	}
	
	for(hor_row=13; hor_row<70; hor_row++){
		gotoxy(hor_row, 22);
			printf("*");
		gotoxy(hor_row, 21);
			printf("*");
		
	}
	
	for(ver_col=4; ver_col<23; ver_col++){
		gotoxy(10, ver_col);
			printf("*");
		gotoxy(11, ver_col);
			printf("*");
		gotoxy(12, ver_col);
			printf("*");
		
		
	}
	
		
	for(ver_col=3; ver_col<23; ver_col++){
		gotoxy(70, ver_col);
			printf("*");
		gotoxy(69, ver_col);
			printf("*");
		gotoxy(68, ver_col);
			printf("*");
		
	}
	
}


int return_if_digit(char c[]){
	int num=0, i=0;
	int size=0;
	while(c[size]!='\0'){
		size+=1;
	}
	for(i=0; i<size; i++){
		if(c[i]>=48 && c[i]<=57){
			continue;
		}
		else{
			//printf("\n\nvalue was : - %c with size :- %d and i = %d and value: - %s\n\n", c[size], size, i, c);
			return -1;
		}
	}
	
	i=0;
		while(c[i]==48){
			c[size] = '\0';
			i++;			
		}
	int carry=1;
	while(size--){
		if(c[size]!='\0'){
			//printf("\t%d", num);
		num= num + ((c[size] - 48)*carry);
		carry= carry * 10;
	}
	}
		
	return num;
}



void back_exit(){
	int c;
	gotoxy(35,21);
	printf("1. back ");
	gotoxy(35,22);
	printf("2. exit ");
	gotoxy(0,24);
	printf("Select(1/2):- ");
	scanf("%d", &c);
	if(c==1){
		
		Welcome();
		
	}
	
	else if(c==2){
		system("clear");
		box();
		gotoxy(28,13);
		printf("Thank You,  Visit again !!");
		gotoxy(0,22);
		exit(0);
		
	}
	
}

void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

 void insert_sort(int r[], int n)
{
   int i, key, j;
   for (i = 1; i < n; i++)
   {
       key = r[i];
        j = i-1;
 
   
       while (j >= 0 && r[j] > key)
       {
           r[j+1] = r[j];
           j = j-1;
       }
       r[j+1] = key;
   }
   print_elements(n);
}
 
void selection_Sorting(int arr[], int n)
{
    int i, j, min;
 
   
    for (i = 0; i < n-1; i++)
    {
       
        min = i;
        for (j = i+1; j < n; j++)
          if (arr[j] < arr[min])
            min = j;
 
       
        swap(&arr[min], &arr[i]);
    }
    print_elements(n);
}

void print_elements( int n){
	int posX=22, posY=12;
	int c;
				for(c = 0; c< 40; c++){
	 gotoxy(c+21, 10);
	 printf("#");
	 if (n<8){
	 gotoxy(c+21, 14);
	 printf("#");
	}
	else {
		gotoxy(c+21, 15);
	 printf("#");
	}
 }
	  for (c = 0; c < n; c++){
		gotoxy(posX, posY);
      printf("%d",srch.elements[c]);
      posX += 5;
      if (posX>= 60){
		  posX =22;
		  posY += 2;
	  }
	}
}

 int checkif_one_two(char s[]){
	 
	 int strlength = 0;
	 
	 while(s[strlength]!='\0'){
		 strlength++;
	 }
	 if(strlength==1){
		 if((s[0]==49 || s[0]==50)){
			 
			 return 0;
		 }
		 else{
			 return 1;
		 }
	 }
	 else{
		  return 1;
	  }
	  
 }
 
  int ifnumber(char s[]){
	 
	 int strlength = 0;
	 
	 while(s[strlength]!='\0'){
		 strlength++;
	 }
	 if(strlength==1){
		 if(s[0]>=49 && s[0]<=57){
			 
			 return 0;
		 }
	 }
	 if(strlength==2){
		 
			if((s[0]>=49 && s[0]<=57) && (s[1]>=48 && s[1]<=57))
			  return 0;
			  
		} 
			 
		
	return 1;
}
	  

int sequential_srch(){
	
	
	 int  search, c, n;
 
	system("clear");
	box();
	
   gotoxy(20,8);
   printf("How many elements you want to enter (1-99) ? \n");
   
   char num[20];
	  int run = 0;
	  do{
			
			if(run==1){
				
					sequential_srch();
			}
			gotoxy(35,10);
			run =1;
			scanf(" %s", num);
		}
		while(ifnumber(num)==1);
		
		if(num[1]=='\0')
			n= (num[0] - 48);
			else
				n = (10 * (num[0] - 48) )+ (num[1] - 48);
			
						
 gotoxy(28, 10);
   printf("Type %d integers\n", n);
	
	 
	int posX=22, posY=12;
   for (c = 0; c < n; c++){
	   
	   int che=0;
	    do{
			gotoxy(posX, posY);
	  	    scanf(" %s",num);
		    che = return_if_digit(num);
		   if (che<0){
			   gotoxy(posX,posY);
			   printf("           ");
			}
	
		}while(che<0);
		srch.elements[c]= che;
		
		posX += 5;
		if (posX>= 60){
		  posX =22;
		  posY += 2;
	  }
  }
	
	system("clear");
	box();
	gotoxy(22,6);
    printf("What element you want to find ? \n");
   	  run = 1;
	  do{
			
			if(run==0){
				system("clear");
				box();
				gotoxy(22,6);
				printf("What element you want to find ? \n");
				
			}
			gotoxy(35,8);
			run =1;
			scanf(" %s", num);
		}
		while(ifnumber(num)==1);
		
		if(num[1]=='\0')
			search= (num[0] - 48);
			else
				search = (10 * (num[0] - 48) )+ (num[1] - 48);
				
				
	selection_Sorting(srch.elements, n);
 
   for (c = 0; c < n; c++)
   {
      if (srch.elements[c] == search)    
      {  gotoxy(25, 17);
         printf("%d is at location %d.", search, c+1);
         gotoxy(25, 19);
         printf("** Sorted with Selection sort **");
         break;
      }
   }
   if (c == n){
	    gotoxy(25, 17);
      printf("%d is not present in array.\n", search);
      gotoxy(25, 19);
         printf("** Sorted with Selection sort **");
  }
  back_exit();
 
   return 0;
}


int binary_srch(){
	
	system("clear");
	box();
   int c, first, last, middle, search;
	gotoxy(20,8);
   printf("How many elements you want to enter (1-99) ? \n");
   
   char num[20];
	  int run = 0;
	  do{
			
			if(run==1){
				binary_srch();
				
			}
			gotoxy(35,10);
			run =1;
			scanf(" %s", num);
		}
		while(ifnumber(num)==1);
		int n;
		if(num[1]=='\0')
			n= (num[0] - 48);
			else
				n = (10 * (num[0] - 48) )+ (num[1] - 48);
			
 gotoxy(31, 10);
   printf("Type %d integers\n", n);
	
	 
	int posX=22, posY=12;
   for (c = 0; c < n; c++){
	   
	   int che=0;
	    do{
			gotoxy(posX, posY);
	  	    scanf(" %s",num);
		    che = return_if_digit(num);
		   if (che<0){
			   gotoxy(posX,posY);
			   printf("           ");
			}
	
		}while(che<0);
		srch.elements[c]= che;
		
		posX += 5;
		if (posX>= 60){
		  posX =22;
		  posY += 2;
	  }
  }
     
	system("clear");
	box();
	gotoxy(22,6);
    printf("What element you want to find ? \n");
   	  run = 0;
	  do{
			
			if(run==1){
				system("clear");
				box();
				gotoxy(22,6);
				printf("What element you want to find ? \n");
				
			}
			gotoxy(35,8);
			run =1;
			scanf(" %s", num);
		}
		while(ifnumber(num)==1);
		
		if(num[1]=='\0')
			search= (num[0] - 48);
			else
				search = (10 * (num[0] - 48) )+ (num[1] - 48);
		
 
	insert_sort(srch.elements, n);
   first = 0;
   last = n - 1;
   middle = (first+last)/2;
 
   while (first <= last) {
      if (srch.elements[middle] < search)
         first = middle + 1;    
      else if (srch.elements[middle] == search) {
		  gotoxy(25, 17);
         printf("%d found at location %d.\n", search, middle+1);
         gotoxy(25, 19);
      printf("** Sorted using Insertion sort **");
         break;
      }
      else
         last = middle - 1;
 
      middle = (first + last)/2;
   }
   if (first > last){
   gotoxy(25, 17);
      printf("%d is not found in the list.\n", search);
      gotoxy(25, 19);
      printf("** Sorted using Insertion sort **");
  }
 
	back_exit();
	return 0;
}

void search_str(){
	
	system("clear");
	box();
	
	if(str[0].names[0]!='0'){
		gotoxy(25,12);
		printf("Sorry ! no elements in Database !");
		back_exit();
	}
	
}


void input_str(){
	
	
}
void for_string(){
	 char select_1_2[10]="garbage";
	  
	  do{
			gotoxy(18, 19);
			printf("Select option (1/2):- ");
			
			if(select_1_2[2]!='r' && select_1_2[5]!='a'){
				for_string();
				
			}
			gotoxy(40,19);
			scanf(" %s", select_1_2);
		}
		while(checkif_one_two(select_1_2)==1);
	
	if(select_1_2[0] == 49){
		
		search_str();
	}
	else{
		input_str();
	}
		
		
	
	
	
}

 int go_now(){
	 
	   char select_1_2[10]="garbage";
	  
	  do{
			gotoxy(18, 19);
			printf("Select option (1/2):- ");
			
			if(select_1_2[2]!='r' && select_1_2[5]!='a'){
				Welcome_for_int();
				
			}
			gotoxy(40,19);
			scanf(" %s", select_1_2);
		}
		while(checkif_one_two(select_1_2)==1);
		
	if(select_1_2[0] == 49){
		
		sequential_srch();
	}
	else{
		binary_srch();
	}
		
  
	  
	  return 0;
  }

 
int Welcome_for_int(){
	
	
		  system("clear");
	  
	  box();
		
		
	  /************************************************************************
	   *                                                                      *
	   *                        Topic Of the Program                          *
	   *                                                                      *
	   ************************************************************************/
	   gotoxy(19,6);
	  printf("| \t Implement sequential search and binary |");
	  gotoxy(19,7);
	  printf("| \t  search techniques with numbers \t  |");
	  gotoxy(18,11);
	  /* asking user what metal do he wanna work with  */
	  printf("Which search you would like to work with ?");
	  gotoxy(27, 14);
	  printf("1. Sequential Search ");
	  gotoxy(27, 16);
	  
	  printf("2. Binary Search ");
	 
	 go_now(); 
	  
	  return 0;
  }
  
  
  
  void Welcome_for_string(){
	  
	  
	  
		  system("clear");
	  
	  box();
		
		
	  /************************************************************************
	   *                                                                      *
	   *                        Topic Of the Program                          *
	   *                                                                      *
	   ************************************************************************/
	   gotoxy(19,6);
	  printf("| \t Implement sequential search and binary |");
	  gotoxy(19,7);
	  printf("| \t  search techniques with strings \t  |");
	  gotoxy(18,11);
	  /* asking user what metal do he wanna work with  */
	  printf("What you want to do ?");
	  gotoxy(27, 14);
	  printf("1. Search Names ");
	  gotoxy(27, 16);
	  
	  printf("2. Enter Names ");
	 
	 for_string();
 }
 
 
 void Welcome(){
	 system("clear");
	 box();
	 gotoxy(25,6);
	printf("I want to work with :- ");
	gotoxy(25, 11);
	printf("1. Strings");
	gotoxy(25,13);
	printf("2. Integers");
	
	 char select_1_2[10]="garbage";
	  
	  do{
			gotoxy(18, 19);
			printf("Select option (1/2):- ");
			
			if(select_1_2[2]!='r' && select_1_2[5]!='a'){
				Welcome();
				
			}
			gotoxy(40,19);
			scanf(" %s", select_1_2);
		}
		while(checkif_one_two(select_1_2)==1);
		
	if(select_1_2[0] == 49){
		
		Welcome_for_string();
	}
	else{
		Welcome_for_string();
	}
		
	 
 }
 
 
 
int main() {
	
	Welcome();
	 
	  
	  gotoxy(70,21);
	  /************************************************************************
	   *                                                                      *
	   *    The moment program work is done it will return a zero value       *
	   *    to the main function to show that the program terminated          *
	   *    successfully.                                                     *
	   *                                                                      *
	   ************************************************************************/

	  return 0;
}


