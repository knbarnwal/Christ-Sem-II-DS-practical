#include<stdio.h>
#include<stdlib.h>


void create();
void display();
void insert_begin();
void insert_end();
void insert_pos();
void delete_begin();
void delete_end();
void delete_pos();


struct node
{
        int info;
        struct node *next;
};
struct node *start=NULL;

int main()      //main() starts
{
        int choice, status, temp;
        do
		{
            printf("\n\t\t\t\t***Party Program:****\n");
           // printf("\n\t\t                MENU                             \n");
            printf("\t\t\t---------------------------------------\n");
            printf("\n\t\t\t 1. Organise  Party   \n");
            printf("\n\t\t\t 2.Display Guest codes   \n");
            printf("\n\t\t\t 3.Inset Special guest code     \n");
            printf("\n\t\t\t 4.Guest number with lowest priority   \n");
            printf("\n\t\t\t 5.Manage guest at middle       \n");
            printf("\n\t\t\t 6.Remove Special guest      \n");
            printf("\n\t\t\t 7.Remove low priority guest        \n");
            printf("\n\t\t\t 8.Remove guest with middle priority     \n");
            printf("\n\t\t\t 0.Get Out       \n");
            printf("\n\t\t\t--------------------------------------\n");
            printf("Enter your choice:\t");
            status = scanf("%d",&choice);
            while(status != 1)
            {
            	while((temp=getchar()) != EOF && temp != '\n');
				printf("\n\nInvalid input...\nPlease enter a Valid number: ");
				status = scanf("%d", &choice);
			}
            switch(choice)
            {
                case 1:
                        create();
                        break;
                case 2:
                        display();
                        break;
                case 3: 
                        insert_begin();
                        break;
                case 4:
                        insert_end();
                        break;
                case 5:
                        insert_pos();
                        break;
                case 6:
                        delete_begin();
                        break;
                case 7:
                        delete_end();
                        break;
                case 8:
                        delete_pos();
                        break;
                }
        }while(choice != 0);
        return 0;
}

void create()
{
        struct node *temp,*ptr;
        temp=(struct node *)malloc(sizeof(struct node));
        if(temp==NULL)
        {
                printf("\n Party is FUll:\n");
                exit(0);
        }
        printf("\nEnter the Guest Code:- ");
        scanf("%d",&temp->info);
        temp->next=NULL;
        if(start==NULL)
        {
                start=temp;
        }
        else
        {
                ptr=start;
                while(ptr->next!=NULL)
                {
                        ptr=ptr->next;
                }
                ptr->next=temp;
        }
}

void display()
{
        struct node *ptr;
        if(start==NULL)
        {
                printf("\n No Guest !!\n");
                return;
        }
        else
        {
                ptr=start;
                printf("\nFollowing are the guest codes:- \n");
                while(ptr!=NULL)
                {
                        printf("%d\t",ptr->info );
                        ptr=ptr->next ;
                }
        }
}

void insert_begin()
{
        struct node *temp;
        temp=(struct node *)malloc(sizeof(struct node));
        if(temp==NULL)
        {
                printf("\nOut of Memory Space:\n");
                return;
        }
        printf("\nEnter the Guest Code:\t" );
        scanf("%d",&temp->info);
        temp->next =NULL;
        if(start==NULL)
        {
                start=temp;
        }
        else
        {
                temp->next=start;
                start=temp;
        }
}

void insert_end()
{
        struct node *temp,*ptr;
        temp=(struct node *)malloc(sizeof(struct node));
        if(temp==NULL)
        {
                printf("\nOut of Memory Space:\n");
                return;
        }
        printf("\nEnter the Guest Code:\t" );
        scanf("%d",&temp->info );
        temp->next =NULL;
        if(start==NULL)
        {
                start=temp;
        }
        else
        {
                ptr=start;
                while(ptr->next !=NULL)
                {
                        ptr=ptr->next ;
                }
                ptr->next =temp;
        }
}

void insert_pos()
{
        struct node *ptr,*temp;
        int i,pos;
        temp=(struct node *)malloc(sizeof(struct node));
        if(temp==NULL)
        {
                printf("\nOut of Memory Space:\n");
                return;
        }
        printf("\nEnter the Guest position:\t");
        scanf("%d",&pos);
        printf("\nEnter the Guest Code:\t");
        scanf("%d",&temp->info) ;
 
        temp->next=NULL;
        if(pos==0)
        {
                temp->next=start;
                start=temp;
        }
        else
        {
                for(i=0,ptr=start;i<pos-1;i++)
                {
                        ptr=ptr->next;
                        if(ptr==NULL)
                        {
                                printf("\nPosition not found:[Handle with care]\n");
                                return;
                        }
                }
                temp->next =ptr->next ;
                ptr->next=temp;
        }
}

void delete_begin()
{
        struct node *ptr;
        ptr=(struct node *)malloc(sizeof(struct node));
        if(ptr==NULL)
        {
                printf("\n No Guest Found !!:\n");
                return;
        }
        else
        {
                ptr=start;
                start=start->next ;
                printf("\nRemoved Guest ID is :%d\t",ptr->info);
                free(ptr);
        }
}

void delete_end()
{
        struct node *temp,*ptr;
        if(start==NULL)
        {
                printf("\n No Guest Found !!:");
                exit(0);
        }
        else if(start->next ==NULL)
        {
                ptr=start;
                start=NULL;
                printf("\nThe Removed Guest code is:%d\t",ptr->info);
                free(ptr);
        }
        else
        {
                ptr=start;
                while(ptr->next!=NULL)
                {
                        temp=ptr;
                        ptr=ptr->next;
                }
                temp->next=NULL;
                printf("\nThe removed guest code:- %d\t",ptr->info);
                free(ptr);
        }
}

void delete_pos()
{
        int i,pos;
        struct node *temp,*ptr;
        if(start==NULL)
        {
                printf("\nNo Guest Found:-\n");
                exit(0);
        }
        else
        {
                printf("\nEnter Position of guest to remove:- \t");
                scanf("%d",&pos);
                if(pos==0)
                {
                        ptr=start;
                        start=start->next ;
                        printf("\nThe removed guest is:%d\t",ptr->info  );
                        free(ptr);
                }
                else
                {
                        ptr=start;
                        for(i=0;i<pos;i++)
                        {
                                temp=ptr;
                                ptr=ptr->next ;
                                if(ptr==NULL)
                                {
                                        printf("\nGuest Position not Found:\n");
                                        return;
                                }
                        }
                        temp->next =ptr->next ;
                        printf("\nThe Removed Guest is:%d\t",ptr->info );
                        free(ptr);
                }
        }
}
