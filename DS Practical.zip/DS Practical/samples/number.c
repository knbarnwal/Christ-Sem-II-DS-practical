#include<stdio.h>

int main(){
	
	char s[4]="235";
	int n = s[0] - 48;
	printf("%d", n);
	
	return 0;
	
}
