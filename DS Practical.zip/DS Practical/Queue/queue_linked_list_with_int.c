#include <stdio.h>
#include <stdlib.h>
 
struct node
{
    int info;
    struct node *ptr;
}*front,*rear,*temp,*front1;
 
void insert(int data);
void del();
void display();
void create();
 
int count = 0;
 
int main()
{
    int no, ch;
    int status, tmp;
 
    create();
    do
    {
    	printf("\n\n\n\t\t   Queue using Linked list of integers !!");
    	printf("\n\n\n\t\t\t 1 - Insert element to queue");
	    printf("\n\t\t\t 2 - Delete element from queue");
	    printf("\n\t\t\t 3 - Display elements of queue");
	    printf("\n\t\t\t 0 - Exit");
        printf("\n Enter choice : ");
        status = scanf("%d", &ch);
        while(status != 1)
		{
			while((tmp=getchar()) != EOF && tmp != '\n');
			printf("\nInvalid input...\nPlease enter a number: ");
			status = scanf("%d", &ch);
		}
        switch (ch)
        {
        case 1:
            printf("\nEnter a number : ");
            status = scanf("%d", &no);
            while(status != 1)
			{
				while((tmp=getchar()) != EOF && tmp != '\n');
				printf("\nInvalid input...\nPlease enter a number: ");
				status = scanf("%d", &no);
			}
            insert(no);
            break;
        case 2:
            del();
            break;
        case 3:
            display();
            break;
        }
    }while(ch != 0);
    printf("\nProgram exiting...");
    return 0;
}
 
void create()
{
    front = rear = NULL;
}
 
void insert(int data)
{
    if (rear == NULL)
    {
        rear = (struct node *)malloc(1*sizeof(struct node));
        rear->ptr = NULL;
        rear->info = data;
        front = rear;
    }
    else
    {
        temp=(struct node *)malloc(1*sizeof(struct node));
        rear->ptr = temp;
        temp->info = data;
        temp->ptr = NULL;
 
        rear = temp;
    }
    count++;
}
 
/* Displaying the queue elements */
void display()
{
    front1 = front;
 
    if ((front1 == NULL) && (rear == NULL))
    {
        printf("\nQueue is empty");
        return;
    }
    while (front1 != rear)
    {
        printf("\n%d ", front1->info);
        front1 = front1->ptr;
    }
    if (front1 == rear)
        printf("\n%d", front1->info);
}
 
/* Dequeing the queue */
void del()
{
    front1 = front;
 
    if (front1 == NULL)
    {
        printf("\n Error: Trying to display elements from empty queue");
        return;
    }
    else
        if (front1->ptr != NULL)
        {
            front1 = front1->ptr;
            printf("\n Dequed value : %d", front->info);
            free(front);
            front = front1;
        }
        else
        {
            printf("\n Dequed value : %d", front->info);
            free(front);
            front = NULL;
            rear = NULL;
        }
        count--;
}
