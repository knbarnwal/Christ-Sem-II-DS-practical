// C Language program to implement to the basic operations on String Queue
# include<stdio.h>
# include<string.h>
# define max 10

int ins();
int del();

int main()
{
	char queue[max][80], data[80];
	int front, rear, reply, option,i;
	int status;
	front = rear = -1;
	do
	{
		printf("\n\n\n\t\t Queue using array of strings \n");
		printf("\n\t\t\t\t 1. Insert String in a Queue");
		printf("\n\t\t\t\t 2. Delete String from a Queue");
		printf("\n\t\t\t\t 3. Display");
		printf("\n\t\t\t\t 4. Exit ");
		printf("\n\n\n\t\t Enter your choice: ");
		status = scanf("%d", &option);
		while(status != 1)
		{
			
			printf("\nInvalid input...\nPlease enter a number: ");
			status = scanf("%d", &option);
		}
		switch(option)
		{
			case 1 : // insert
				printf("\n Enter the String to be insert in a Queue : ");
				scanf(" %[^\n]s", data);
				reply = ins(queue, &rear, data);
				if( reply == -1 )
					printf("\n Queue is Full \n");
				else
					printf("\n\t\t **Entered String is Inserted in a Queue** \n");
				break;
			case 2 : // delete
				reply = del(queue, &front, &rear, data);
				if( reply == -1 )
					printf("\n Queue is Empty \n");
				else
					printf("\n Deleted String from Queue is : %s", data);
					printf("\n");
				break;
			case 3 : if (reply <= 0)
        				printf("\nQueue is empty \n");
    				else
				    {
				        printf("\nQueue is : \n");
				        if(rear<0)front=0;
				        for (i = front; i <= rear; i++)
				            printf("%s \n", queue[i]);
				        printf("\n");
				    }
					    break;
		} // switch
	}while(option != 0);
} // main
int ins(char queue[max][80], int *rear, char data[80])
{
	if(*rear == max -1)
		return(-1);
	else
	{
		*rear = *rear + 1;
		strcpy(queue[*rear], data);
		
		return(1);
	} // else
} // insq


int del(char queue[max][80], int *front, int *rear, char data[80])
{
	if(*front == *rear)
		return(-1);
	else
	{
		(*front)++;
		strcpy(data, queue[*front]);
		return(1);
	} // else
} // delq
