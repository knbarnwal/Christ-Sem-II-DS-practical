#include <stdio.h>
#include <math.h>



int main () {
  
  char value[20];
  int num=0;
  
  printf("ENter a number:- ");
  do{
	  printf("\nInvalid value ! \n\nENter a number:- ");
	  scanf(" %s",value);
	num = return_if_digit(value);
			  	  
			  	printf("%d", num)  ;
	  }while(num<0);
		
	printf("Number you enter was:- %d\n\n", num);
	
	main();
   return(0);
}
