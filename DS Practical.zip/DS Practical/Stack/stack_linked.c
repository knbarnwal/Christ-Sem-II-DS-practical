#include<stdio.h>
#include<stdlib.h>

struct Node
{
   int data;
   struct Node *next;
}*head = NULL;


int main();
void push(int);
void pop();
void display();


/*void gotoxy(int x,int y){
	
	printf("%c[%d;%df",0x1B,y,x);
	
}
*/

void gotoxy(int x, int y)
{
  COORD coord;
  coord.X = x;
  coord.Y = y;
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void box(){
	
	int hor_row, ver_col;
	
	for(hor_row=10; hor_row<70; hor_row++){
		gotoxy(hor_row, 3);
			printf("*");
		gotoxy(hor_row, 4);
			printf("*");
		
		
	}
	
	for(hor_row=13; hor_row<70; hor_row++){
		gotoxy(hor_row, 22);
			printf("*");
		gotoxy(hor_row, 21);
			printf("*");
		
	}
	
	for(ver_col=4; ver_col<23; ver_col++){
		gotoxy(10, ver_col);
			printf("*");
		gotoxy(11, ver_col);
			printf("*");
		gotoxy(12, ver_col);
			printf("*");
		
		
	}
	
		
	for(ver_col=3; ver_col<23; ver_col++){
		gotoxy(70, ver_col);
			printf("*");
		gotoxy(69, ver_col);
			printf("*");
		gotoxy(68, ver_col);
			printf("*");
		
	}
	
}


  int ifnumber(char s[]){
	 
	 int strlength = 0;
	 
	 while(s[strlength]!='\0'){
		 strlength++;
	 }
	 if(strlength==1){
		 if(s[0]>=49 && s[0]<=52){
			 
			 return 0;
		 }
	 }
	 
		
	return 1;
}
	  
void back_exit(){
	int c;
	gotoxy(35,21);
	printf("1. back ");
	gotoxy(35,22);
	printf("2. exit ");
	gotoxy(0,24);
	printf("Select(1/2):- ");
	
	
	
   char num[20];
	 
      
       do{
			
			gotoxy(15,24);
			printf("                 ");
			
			gotoxy(15,24);
			
			scanf(" %s", num);
			
		}
		while(ifnumber(num)==1);
		
		if(num[1]=='\0')
			c= (num[0] - 48);
			
		
	
	
	if(c==1){
		
		main();
		
	}
	
	else if(c==2){
		system("cls");
		box();
		gotoxy(28,13);
		printf("Thank You,  Visit again !!");
		gotoxy(0,22);
		exit(0);
		
	}
	
}

int chal_jamura(){
		

   int choice, value;
	
	
     gotoxy(20, 11);
				printf("What u wanna do Bro ?");
				gotoxy(33, 13);
				printf("1. Push\n\t\t\t\t2. Pop\n\t\t\t\t3. Display");
				gotoxy(15,20);
				printf("Select (1-3):- ");
				
      static int try=0;
      if(try == 1){
		  gotoxy(25,23);
				printf(" try again !!!");
			}
      
   char num[20];
	  int run = 0;
      
       do{
			
			if(run==1){
				system("cls");
				box();
				chal_jamura();
				
				
				
			}
			gotoxy(30,20);
			printf("                 ");
			run =1;
			gotoxy(30,20);
			
			scanf(" %s", num);
			try=1;
		}
		while(ifnumber(num)==1);
		
		if(num[1]=='\0')
			choice= (num[0] - 48);
			else
				choice = (10 * (num[0] - 48) )+ (num[1] - 48);
		
      
      try=0;
      
      
      
      
      switch(choice){
		 case 1:	
				 system("cls");
				 box();
				 gotoxy(17,10);
				 printf("Enter the value to be insert:- ");
				 scanf("%d", &value);
				 push(value);
				 
				 back_exit();
				 break;
		 case 2: system("cls");
				 box();
				 pop(); 
				 
				 back_exit(); 
				 break;
		 case 3: system("cls");
				 box();
				 display(); 
				 back_exit();
				 break;
		 
	 
      }
   
   return 0;
}
int main()
{
	system("cls");
   box();
   gotoxy(20,7);
   printf(" Implementation of Stack using Linked List ");
   gotoxy(18,5);
   printf("==============================================");
   gotoxy(18,9);
   printf("==============================================");
   
   chal_jamura();
   return 0;
}
void push(int value)
{
   struct Node *list;
   list = (struct Node*)malloc(sizeof(struct Node));
   list->data = value;
   if(head == NULL)
      list->next = NULL;
   else
      list->next = head;
   head = list;
   gotoxy(25, 15);
   printf("Insertion done Bro !!!");
}
void pop()
{
   if(head == NULL){
	gotoxy(25,15);
      printf("Error(404), Empty Stack !!!");
  }
   else{
      struct Node *temp = head;
      gotoxy(25,15);
      printf("Element Popped :- %d", temp->data);
      head = temp->next;
      free(temp);
   }
}


void display()
{
   if(head == NULL){
	   gotoxy(21,10);
      printf("Nothing to see in empty stack bro ????");
      gotoxy(33,15);
      printf("{*_*}  {*_*}");
      gotoxy(37,17);
      printf("{*_*}");
  }
   else{
      struct Node *temp = head;
      int c=23;
       gotoxy(c, 10);
      while(temp->next != NULL){
		  
		 
	 printf("%d  ",temp->data);
	 temp = temp -> next;
	
      }
      gotoxy(23, 15);
      printf("%d <---> NULL",temp->data);
   }
}
