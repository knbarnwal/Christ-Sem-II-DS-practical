#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

void push(struct Node** head_ref, int new_data)
{
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));

    new_node->data  = new_data;
    new_node->next = (*head_ref);
	/* make head point to the new node */
    (*head_ref)    = new_node;
}
 
/* Print the elements of the linked list*/
void printList(struct Node *node)
{
    while (node != NULL)
    {
        printf("%d\t", node->data);
        node = node->next;
    }
    printf("\n");
}
 
/* Returns the last node of the list as cur */
struct Node *getTail(struct Node *cur)
{
    while (cur != NULL && cur->next != NULL)
        cur = cur->next;
    return cur;
}
 
/* The list is partitioned by considering the last element as pivot */
struct Node *partition(struct Node *head, struct Node *end,
                       struct Node **newHead, struct Node **newEnd)
{
    struct Node *pivot = end;
    struct Node *prev = NULL, *cur = head, *tail = pivot;
 
    // During partition, both the head and end of the list might change
    // which is updated in the newHead and newEnd variables
    while (cur != pivot)
    {
        if (cur->data < pivot->data)
        {
            // First node that has a value less than the pivot - becomes
            // the new head
            if ((*newHead) == NULL)
                (*newHead) = cur;
 
            prev = cur;  
            cur = cur->next;
        }
        else // If cur node is greater than pivot
        {
            // Move cur node to next of tail, and change tail
            if (prev)
                prev->next = cur->next;
            struct Node *tmp = cur->next;
            cur->next = NULL;
            tail->next = cur;
            tail = cur;
            cur = tmp;
        }
    }
 
    // If the pivot data is the smallest element in the current list,
    // pivot becomes the head
    if ((*newHead) == NULL)
        (*newHead) = pivot;
 
    // Update newEnd to the current last node
    (*newEnd) = tail;
 
    // Return the pivot node
    return pivot;
}
 
 
//here the sorting happens exclusive of the end node
struct Node *quickSortRecur(struct Node *head, struct Node *end)
{
    // base condition
    if (!head || head == end)
        return head;
 
    struct Node *newHead = NULL, *newEnd = NULL;
 
    // Partition the list, newHead and newEnd will be updated
    // by the partition function
    struct Node *pivot = partition(head, end, &newHead, &newEnd);
 
    // If pivot is the smallest element - no need to recur for
    // the left part.
    if (newHead != pivot)
    {
        // Set the node before the pivot node as NULL
        struct Node *tmp = newHead;
        while (tmp->next != pivot)
            tmp = tmp->next;
        tmp->next = NULL;
 
        // Recur for the list before pivot
        newHead = quickSortRecur(newHead, tmp);
 
        // Change next of last node of the left half to pivot
        tmp = getTail(newHead);
        tmp->next =  pivot;
    }
 
    // Recur for the list after the pivot element
    pivot->next = quickSortRecur(pivot->next, newEnd);
 
    return newHead;
}
 
// The main function for quick sort. This is a wrapper over recursive
// function quickSortRecur()
void quickSort(struct Node **headRef)
{
    (*headRef) = quickSortRecur(*headRef, getTail(*headRef));
    return;
}
 
// Main program starts here
int main()
{
    struct Node *a = NULL;
    int n,arr[50],i;
    int status,temp;
    printf("Enter the number elements you want to sort :\n");
    status = scanf("%d",&n);
    while(status != 1)
            {
            	while((temp=getchar()) != EOF && temp != '\n');
				printf("\n\nInvalid input...\nPlease enter a number: ");
				status = scanf("%d", &n);
			}
    printf("Enter the list of elements\n");
    for(i=0;i<n;i++)
    {
    	printf("\nElement %d: ",(i+1));
    	status = scanf("%d",&arr[i]);
    	while(status != 1)
            {
            	while((temp=getchar()) != EOF && temp != '\n');
				printf("\n\nInvalid input...\nPlease enter a number: ");
				status = scanf("%d", &arr[i]);
			}
	}
	for(i=0;i<n;i++)
    {
    	push(&a,arr[i]);
	}
    
 
    printf("\n\nLinked List before quick-sorting: \n");
    for(i=0;i<n;i++)
    {
    	printf("%d\t",arr[i]);
	}
 	printf("\n");
 	
    quickSort(&a);
 
    printf("\n\nLinked List after quick-sorting: \n");
    printList(a);
 
    return 0;
}
